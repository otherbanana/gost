#!/system/bin/sh
logfile="/sdcard/supppig_debug.txt"
echo "net表" >$logfile
iptables -t nat -vnL >>$logfile

echo "" >>$logfile
echo "mangle表" >>$logfile
iptables -t mangle -vnL >>$logfile

echo "" >>$logfile
echo "filter表" >>$logfile
iptables -t filter -vnL >>$logfile

echo "" >>$logfile
echo "raw表" >>$logfile
iptables -t raw -vnL >>$logfile

echo "" >>$logfile
echo "ps执行结果" >>$logfile
ps >>$logfile

echo "执行完成。发送$logfile 给我吧~~"